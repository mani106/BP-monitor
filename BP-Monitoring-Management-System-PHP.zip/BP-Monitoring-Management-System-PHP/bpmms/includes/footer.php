 <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>BP Monitoring Management System</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->