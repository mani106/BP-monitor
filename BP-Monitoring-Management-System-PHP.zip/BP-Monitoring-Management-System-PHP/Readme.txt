How to run the BP Monitoring Management System (bpmms) Project
1. Download the zip file

2. Extract the file and copy bpmms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name bpmmsdb

6. Import bpmmsdb.sql file(given inside the zip package in the SQL file folder)

7. Run the script http://localhost/bpmms

Credential for User panel :

Username: john@test.com
Password: Test@123